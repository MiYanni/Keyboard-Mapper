﻿#if UNIT_TEST
#pragma warning disable 1591
// ReSharper disable InconsistentNaming

using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace $rootnamespace$
{
    [ExcludeFromCodeCoverage]
    [TestFixture]
    internal sealed class $safeitemname$
    {
        [Test]
        public void $safeitemname$_MethodName_Condition()
        {
        }
    }
}

// ReSharper restore InconsistentNaming
#pragma warning restore 1591
#endif